import numpy as np

def multiplication_grid(n: int) -> np.ndarray:
    """Return the n x n multiplication table M where M[i,j]=(i+1)*(j+1)."""
    x = np.arange(1, n+1)
    return np.outer(x, x)

def guasti_accumulate(a: np.ndarray, X: int, Y: int) -> np.ndarray:
    """Accumulate a(n) over factor pairs (x,y) with x*y=n."""
    G = np.zeros((X, Y), dtype=float)
    N = min(len(a)-1, X*Y)
    for n in range(1, N+1):
        val = a[n]
        if val == 0:
            continue
        d = 1
        while d*d <= n:
            if n % d == 0:
                x, y = d, n//d
                if x<=X and y<=Y:
                    G[x-1, y-1] += val
                if x != y:
                    x2, y2 = y, d
                    if x2<=X and y2<=Y:
                        G[x2-1, y2-1] += val
            d += 1
    return G

if __name__ == '__main__':
    try:
        import sympy as sp
    except ImportError:
        raise SystemExit('Please install sympy: pip install sympy')
    N = 50
    a = np.zeros(N+1)
    for p in sp.primerange(1, N+1):
        a[p] = 1.0
    G = guasti_accumulate(a, X=12, Y=12)
    print(G)
