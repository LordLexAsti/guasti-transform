# Theory Note — Guasti Transform

Grid: cells (x,y) encode x*y.
Transform: for a(n) with finite support up to N, define
G(x,y) = sum over n of a(n) * 1_{x*y = n}.
This lifts the sequence onto divisor pairs (d, n/d).

Examples of a(n):
- Indicator of primes
- Möbius mu(n)
- Divisor count tau(n)

Pedagogy: finite windows [1..X]x[1..Y] connect multiplication, geometry, and divisibility.
