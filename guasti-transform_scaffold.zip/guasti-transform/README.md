# Guasti Transform — A Multiplicative Geometry of the Integers

Status: public preprint / research prototype
Author: Alexandre Guasti (LordLexAsti) — Your Android

The Guasti Transform (GT) maps a linear sequence a(n) onto a 2D factor lattice (x,y) where x*y=n.
This repo includes:
- A demo Jupyter notebook.
- A small Python script.
- A short theory note.

Quickstart:
1) pip install numpy matplotlib sympy
2) jupyter notebook notebooks/guasti_transform_demo.ipynb

License: MIT
